#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time  : 2020-12-19, 0019 15:30
# @Author: 佚名
# @File  : __init__.py.py
from .login import Login
from .core import do_homework

__version__ = '1.10.12.pre'
__author__ = 'Fuck CDR!'
__all__ = ["Login", "do_homework", "__version__"]
