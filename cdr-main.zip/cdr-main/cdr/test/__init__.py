#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time  : 2020-12-25, 0025 10:09
# @Author: 佚名
# @File  : __init__.py.py
from .class_task import ClassTask
from .myself_task import MyselfTask

__all__ = ["ClassTask", "MyselfTask"]
