# 词达人-全自动版

![python-version](https://img.shields.io/badge/python-3.9.4-brightgreen.svg)

#### 支持班级及自选任务
#### 使用须知
注意：当你使用该软件，默认满足以下条件
1. 任务点你自己做不做都一个样（答题对你没有任何能力上的提升）
2. 答题是在浪费你的时间（原因详见上一条）
3. 你想挤出一些时间用于自己的兴趣爱好/提升专业能力
4. 你并不会因为考试及格而担忧（无论是学校自主考试亦或者借助第三方平台进行的考试）

如不满足上述任意条件，建议拉黑该软件。自己动手，丰衣足食
#### 如何运行？
##### 你可以采用一下指令安装第三方依赖
`pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/`
##### 或者使用以下指令
`pip install Pillow qrcode requests aiohttp -i https://mirrors.aliyun.com/pypi/simple/`
##### 在确保你已经安装好相关第三方库后，使用`python main.py`执行
##### Release中不再提供打包好的exe文件，若有需要请自行审查代码并打包编译
> 欢迎提交Issues来帮助我更好的完善此项目

##### 不会支持的功能
竞赛
